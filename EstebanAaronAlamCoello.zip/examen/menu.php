<ul>
  <li>Esteban Aaron</li>
  <li>
    <a href="projects.php">Proyectos</a>
  </li>
  <li>
    <a href="create-project.php">Crear un proyecto</a>
  </li>
</ul>